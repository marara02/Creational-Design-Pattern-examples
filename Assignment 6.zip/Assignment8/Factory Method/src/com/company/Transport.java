package com.company;

public interface Transport {
    void deliver();
}
