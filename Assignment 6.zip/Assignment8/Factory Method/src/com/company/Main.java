package com.company;

public class Main {

    public static void main(String[] args) {
	TransportChose tt = new TransportChose();
	System.out.println(tt.getType());
    }
}
