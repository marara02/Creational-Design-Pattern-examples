package com.company;

public class Truck implements Transport {
    @Override
    public void deliver() {
        System.out.println("Your food will deliver by car or bike");
    }
}
