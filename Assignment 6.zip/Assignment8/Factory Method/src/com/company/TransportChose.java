package com.company;

import java.util.Scanner;

public class TransportChose{
    Truck tr = new Truck();
    Ship s = new Ship();
    public Transport getType() {
        System.out.println("Choose way for deliver:");
        System.out.println("1.Truck");
        System.out.println("2.Ship");
        Scanner ss = new Scanner(System.in);
        int n = ss.nextInt();
         if(n==1) {
             tr.deliver();
            // return new Truck();
         }
         if(n==2) {
             s.deliver();
            // return new Ship();
         }
         return null;
    }
}
