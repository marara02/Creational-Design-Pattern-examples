package com.company;

public interface Chair {
    void sit();
    void design();
    void result();
}
