package com.company;

public class VictorianCoffeeTable implements CoffeeTable {
    @Override
    public void height() {
        System.out.println("Height:80sm");
    }

    @Override
    public void design() {
        System.out.println("Colors:brown, creme");
    }

    @Override
    public void result() {
        System.out.println("You order Victorian Coffee Table :)");
        height();
        design();
    }
}
