package com.company;

public class ModernChair implements Chair {
    private String color;
    private int cost;

    public ModernChair(String color,int cost){
        this.color = color;
        this.cost = cost;
    }
    @Override
    public void sit() {
        System.out.println("Form of sits is rectangle :)");
        System.out.println("Cost:"+this.cost);
    }

    @Override
    public void design() {
        System.out.println("With all wishes our modern customers");
        System.out.println("Color:"+this.color);
    }

    @Override
    public void result() {
        System.out.println("You order Modern chair:)");
        sit();
        design();
    }
}
