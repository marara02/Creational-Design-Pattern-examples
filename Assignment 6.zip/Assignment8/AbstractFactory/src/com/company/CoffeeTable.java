package com.company;

public interface CoffeeTable {
    void height();
    void design();
    void result();
}
