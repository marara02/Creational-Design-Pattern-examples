package com.company;

public interface AbstractFactories {
    Chair createChair();
    CoffeeTable createCoffeeTable();
}
