package com.company;

public class ModernFurnitureFactory implements AbstractFactories {
    @Override
    public Chair createChair() {
        return new ModernChair("White",100);
    }

    @Override
    public CoffeeTable createCoffeeTable() {
        return new ModernCoffeeTable();
    }
}
