package com.company;

import java.awt.desktop.ScreenSleepEvent;
import java.util.Scanner;

public class Main {
 public static Factories clients(){
     Factories ff;
     AbstractFactories abstractFactories;
     System.out.println("-----------------------Choose furniture------------------------");
     System.out.println("1.modern;");
     System.out.println("2.victorian;");
     Scanner scanner = new Scanner(System.in);
     String type = scanner.nextLine();
     if(type.equals("modern")) {
         abstractFactories = new ModernFurnitureFactory();
         ff = new Factories(abstractFactories);
     }
  else{
         abstractFactories = new VictorianFurnitureFactory();
         ff = new Factories(abstractFactories);
     }
     return ff;
     }
    public static void main(String[] args) {
     try {
	Factories factories = clients();
	factories.Results();
    }
     catch (Exception e){
         System.out.println("Something went wrong");
     }
     }
}
