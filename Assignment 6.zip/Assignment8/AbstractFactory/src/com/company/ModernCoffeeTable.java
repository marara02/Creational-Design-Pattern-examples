package com.company;

public class ModernCoffeeTable implements CoffeeTable {
    @Override
    public void height() {
        System.out.println("Height is:65sm");
    }

    @Override
    public void design() {
        System.out.println("Colors:white,black");
    }

    @Override
    public void result() {
        System.out.println("You order Modern Coffee Table:)");
        height();
        design();
    }
}
