package com.company;

public class Factories {
    private Chair chair;
    private CoffeeTable coffeeTable;
    public Factories(AbstractFactories abstractFactories){
        chair = abstractFactories.createChair();
        coffeeTable = abstractFactories.createCoffeeTable();
    }
    public void Results(){
        chair.result();
        coffeeTable.result();
    }
}
