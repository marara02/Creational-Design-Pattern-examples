package com.company;

public class VictorianChair implements Chair {
    @Override
    public void sit() {
        System.out.println("Form of sits is in design of 18 century");
    }

    @Override
    public void design() {
        System.out.println("Design have been come since 18 century");
    }

    @Override
    public void result() {
        System.out.println("You order Victorian chair :)");
        sit();
        design();
    }
}
