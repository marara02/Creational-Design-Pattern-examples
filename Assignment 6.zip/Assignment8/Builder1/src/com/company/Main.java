package com.company;

public class Main {

    public static void main(String[] args) {
	Builder concreteBuilder1 = new ConcreteBuilder1();
        Director director = new Director(concreteBuilder1);
        System.out.println("---------------------ConcreteBuilder1---------------------");
        director.buildHouse();
        House house = director.getResult();
        System.out.println("Builder constructed: "+ house);
    }
}
