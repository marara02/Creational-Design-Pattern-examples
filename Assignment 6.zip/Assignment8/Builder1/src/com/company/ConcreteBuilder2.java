package com.company;

public class ConcreteBuilder2 implements Builder {
    private House house;
    public ConcreteBuilder2(){
        this.house = new House();
    }
    @Override
    public void buildStep1() {
        house.setBase("Walls with graphic design");
        house.getBase();
    }

    @Override
    public void buildStep2() {
      house.setDoor(8);
      house.setWindow(12);
      house.getDoor();
      house.getWindow();
    }

    @Override
    public void buildStep3() {
      house.setAlternative("Garage,Swimming pool and garden");
      house.getAlternative();
    }

    @Override
    public House getResult() {
        return this.house;
    }
}
