package com.company;

public interface Builder {
    void buildStep1();
    void buildStep2();
    void buildStep3();
    House getResult();
}
