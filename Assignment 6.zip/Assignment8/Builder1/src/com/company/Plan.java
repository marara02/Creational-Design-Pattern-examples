package com.company;

public interface Plan {
    public void setBase(String base);
    public String getBase();
    public void setWindow(int w);
    public int getWindow();
    public void setDoor(int door);
    public int getDoor();
    public void setAlternative(String alternative);
    public String getAlternative();
}
