package com.company;

public class ConcreteBuilder1 implements Builder {
    private House house;

    public ConcreteBuilder1(){
        this.house = new House();
    }
    @Override
    public void buildStep1() {
        house.setBase("Walls for house!");
        System.out.println(house.getBase());
    }

    @Override
    public void buildStep2() {
        house.setDoor(5);
        house.setWindow(4);
        System.out.println("Doors at house:"+house.getDoor());
        System.out.println("Windows at house:"+house.getWindow());
    }

    @Override
    public void buildStep3() {
    house.setAlternative("Mini garage for little car");
    System.out.println(house.getAlternative());
    }
    @Override
    public House getResult() {
        return this.house;
    }
}