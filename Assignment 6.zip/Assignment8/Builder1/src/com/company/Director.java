package com.company;

public class Director {
    private Builder builder;

    public Director(Builder builder) {
        this.builder = builder;
    }

    public House getResult() {
        return this.builder.getResult();
    }

    public void buildHouse() {
        this.builder.buildStep1();
        this.builder.buildStep2();
        this.builder.buildStep3();
    }
}
