package com.company;

public class House implements Plan {
    private String basement;
    private String alternative;
    private int window;
    private int door;

    @Override
    public void setBase(String base) {
        this.basement = base;
    }

    @Override
    public String getBase() {
        return this.basement;
    }

    @Override
    public void setWindow(int w) {
        this.window = w;
    }

    @Override
    public int getWindow() {
        return this.window;
    }

    @Override
    public void setDoor(int door) {
       this.door = door;
    }

    @Override
    public int getDoor() {
        return this.door;
    }

    @Override
    public void setAlternative(String alternative) {
        this.alternative = alternative;
    }

    @Override
    public String getAlternative() {
        return this.alternative;
    }
}
