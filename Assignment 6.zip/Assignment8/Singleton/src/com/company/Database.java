package com.company;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
        private static Database instance;
        private Connection connection;
        private Database() {
            System.out.println("-----------MySQL------------");

            try {

                Class.forName("com.mysql.jdbc.Driver");

            } catch (ClassNotFoundException e) {

                System.out.println("Where is MySQL JDBC Driver? "
                        + "Include in your library path!");
                e.printStackTrace();
                return;

            }

            System.out.println("MySQL JDBC Driver Registered!");

            try {

                connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/exam"
                        ,"root","123456");

            } catch (SQLException e) {
                System.out.println("Connection Failed! Check output console");
                e.printStackTrace();

            }
        }
        public static Database getInstance() {
            if (Database.instance == null)
                Database.instance = new Database();
            return Database.instance;
        }
        public void query(String sql) {
            try {
                Statement stmt = connection.createStatement();
                ResultSet resultSet = stmt.executeQuery(sql);
                while(resultSet.next())
                    System.out.printf("%-30.30s  %-30.30s%n", resultSet.getString("Course_name"),
                            resultSet.getString("Student_name"));
            }
                 catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

