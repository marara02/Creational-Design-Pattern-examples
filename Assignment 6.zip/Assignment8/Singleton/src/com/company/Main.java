package com.company;

public class Main {

    public static void main(String[] args) {
        Database foo = Database.getInstance();
        foo.query("SELECT * FROM exams");
        Database bar = Database.getInstance();
        bar.query("SELECT * FROM exams");

    }
}
